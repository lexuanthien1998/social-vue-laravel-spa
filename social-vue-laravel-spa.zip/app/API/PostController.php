<?php

namespace App\API;

use Illuminate\Database\Eloquent\Model;

class PostController extends Model
{
    //
}
